using UnityEngine;

[CreateAssetMenu(fileName = "NewGameMode", menuName = "Game/GameMode")]
public class GameModeSO : ScriptableObject
{
    public int goalScore;

}

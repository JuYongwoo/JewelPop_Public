using System;
using UnityEngine;

public class InputManager
{
    
    public void OnUpdate()
    {
        AppManager.instance.actionManager.StageSceneInputController?.Invoke();

    }
    
}
